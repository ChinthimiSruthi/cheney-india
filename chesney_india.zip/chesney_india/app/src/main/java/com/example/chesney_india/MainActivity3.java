package com.example.chesney_india;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Point;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.FirebaseApp;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.journeyapps.barcodescanner.BarcodeEncoder;

import java.util.HashMap;
import java.util.Map;

public class MainActivity3 extends AppCompatActivity {

    private ImageView qrCodeIV;
    private TextView deviceCodeTV;
    private ImageView homeButton;
    private FirebaseFirestore firestore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Set the activity to full-screen mode
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                        View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                        View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                        View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                        View.SYSTEM_UI_FLAG_FULLSCREEN |
                        View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        );

        setContentView(R.layout.activity_main3);

        // Initialize Firebase
        try {
            FirebaseApp.initializeApp(this);
            firestore = FirebaseFirestore.getInstance();
            Log.d("Firebase", "Firebase initialized successfully");
        } catch (Exception e) {
            Log.e("Firebase", "Failed to initialize Firebase", e);
            Toast.makeText(this, "Error initializing Firebase", Toast.LENGTH_SHORT).show();
        }

        qrCodeIV = findViewById(R.id.qrCodeIV);
        deviceCodeTV = findViewById(R.id.deviceCodeTV);
        homeButton = findViewById(R.id.homeButton);

        // Set up home button click listener to navigate to settings
        homeButton.setOnClickListener(v -> navigateToSettings());

        // Generate QR code automatically as soon as the activity is opened
        generateAndDisplayQRCode();
    }

    private void generateAndDisplayQRCode() {
        try {
            // Get the unique device code
            String deviceCode = getUniqueDeviceCode();
            deviceCodeTV.setText(deviceCode);
            deviceCodeTV.setVisibility(View.VISIBLE);

            // Log the device code
            Log.d("Device ID", "Unique Device ID: " + deviceCode);

            // Generate and display the QR code
            generateQRCode(deviceCode);

            // Save the device code to Firebase
            saveQRDataToFirebase(deviceCode);

            qrCodeIV.setVisibility(View.VISIBLE);
            homeButton.setVisibility(View.VISIBLE);

            // Start listening for updates on this device's data
            listenForMediaUpdates(deviceCode);

        } catch (Exception e) {
            Log.e("QR Code", "Failed to generate QR Code", e);
            Toast.makeText(this, "Error generating QR Code", Toast.LENGTH_SHORT).show();
        }
    }

    private String getUniqueDeviceCode() {
        String deviceID = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        Log.d("Device ID", "Fetched Device ID: " + deviceID);
        return deviceID != null ? deviceID : "Unknown Device ID";
    }

    private void generateQRCode(String text) {
        BarcodeEncoder barcodeEncoder = new BarcodeEncoder();
        try {
            Bitmap bitmap = barcodeEncoder.encodeBitmap(text, BarcodeFormat.QR_CODE, 400, 400);
            qrCodeIV.setImageBitmap(bitmap);
        } catch (WriterException e) {
            Log.e("QR Code", "Error generating QR Code bitmap", e);
            Toast.makeText(this, "Error generating QR Code image", Toast.LENGTH_SHORT).show();
        }
    }

    private void navigateToSettings() {
        Intent intent = new Intent(MainActivity3.this, SettingsActivity.class);
        startActivity(intent);
    }

    private void saveQRDataToFirebase(String deviceCode) {
        try {
            DocumentReference documentRef = firestore.collection("device_ids").document(deviceCode);
            documentRef.get().addOnSuccessListener(documentSnapshot -> {
                if (!documentSnapshot.exists()) {
                    Map<String, Object> deviceData = new HashMap<>();
                    deviceData.put("deviceCode", deviceCode);
                    deviceData.put("media", null);
                    documentRef.set(deviceData)
                            .addOnSuccessListener(aVoid -> Log.d("Firebase", "Device code and media (null) saved successfully"))
                            .addOnFailureListener(e -> {
                                Log.e("Firebase", "Failed to save device data", e);
                                Toast.makeText(this, "Error saving data to Firebase", Toast.LENGTH_SHORT).show();
                            });
                } else {
                    Log.d("Firebase", "Device code already exists, not overwriting media");
                }
            }).addOnFailureListener(e -> Log.e("Firebase", "Error checking device existence", e));
        } catch (Exception e) {
            Log.e("Firebase", "Error saving device data to Firebase", e);
            Toast.makeText(this, "Error saving data to Firebase", Toast.LENGTH_SHORT).show();
        }
    }

    private void listenForMediaUpdates(String deviceCode) {
        DocumentReference deviceDocRef = firestore.collection("device_ids").document(deviceCode);
        deviceDocRef.addSnapshotListener((documentSnapshot, e) -> {
            if (e != null) {
                Log.e("Firestore", "Error listening for updates", e);
                return;
            }

            if (documentSnapshot != null && documentSnapshot.exists()) {
                String mediaUrl = documentSnapshot.getString("media");

                if (mediaUrl == null || mediaUrl.isEmpty()) {
                    Log.d("Media", "Media is null or empty. Displaying QR Code.");
                    qrCodeIV.setVisibility(View.VISIBLE);
                } else {
                    Intent intent = new Intent(MainActivity3.this, MainActivity4.class);
                    intent.putExtra("mediaUrl", mediaUrl);
                    startActivity(intent);
                }
            }
        });
    }
}
