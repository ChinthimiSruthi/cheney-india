package com.example.chesney_india;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class SettingsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings); // Ensure this matches your layout file name

        // Enable immersive mode to hide the taskbar and navigation bar
        hideSystemUI();

        // Setup buttons and interactions
        findViewById(R.id.cleanMemory).setOnClickListener(v -> cleanMemory());
        findViewById(R.id.connectWifi).setOnClickListener(v -> connectToWifi());
        findViewById(R.id.openDeviceSettings).setOnClickListener(v -> openDeviceSettings());
        findViewById(R.id.logOut).setOnClickListener(v -> logOut());
        findViewById(R.id.checkUpdate).setOnClickListener(v -> checkForUpdates());
        findViewById(R.id.goBack).setOnClickListener(v -> finish());
        findViewById(R.id.reload).setOnClickListener(v -> recreate());
        findViewById(R.id.appVersion).setOnClickListener(v -> showAppVersion());
        findViewById(R.id.exitApp).setOnClickListener(v -> exitApp());
    }

    // Method to hide the system UI for immersive mode
    private void hideSystemUI() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        );
    }

    @Override
    protected void onResume() {
        super.onResume();
        hideSystemUI(); // Reapply immersive mode when the activity resumes
    }

    // Method to simulate memory cleaning
    private void cleanMemory() {
        Toast.makeText(this, "Memory cleaned", Toast.LENGTH_SHORT).show();
    }

    // Method to open Wi-Fi settings
    private void connectToWifi() {
        startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS));
    }

    // Method to open device settings
    private void openDeviceSettings() {
        startActivity(new Intent(Settings.ACTION_SETTINGS));
    }

    // Method to log out and go back to QR code page (MainActivity3)
    private void logOut() {
        Toast.makeText(this, "Logged out", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(SettingsActivity.this, MainActivity3.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }

    // Mock method to simulate checking for updates
    private void checkForUpdates() {
        Toast.makeText(this, "Checking for updates...", Toast.LENGTH_SHORT).show();
    }

    // Method to show app version
    private void showAppVersion() {
        Toast.makeText(this, "App Version: 1.0.0", Toast.LENGTH_SHORT).show();
    }

    // Method to exit the app and go back to QR code page (MainActivity3)
    private void exitApp() {
        Intent intent = new Intent(SettingsActivity.this, MainActivity3.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finishAffinity();
    }
}
