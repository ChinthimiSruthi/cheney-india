package com.example.chesney_india;

public class Media {
    private String fileName;
    private String filePath;

    public Media() {
        // Default constructor required for calls to DataSnapshot.getValue(Media.class)
    }

    public Media(String fileName, String filePath) {
        this.fileName = fileName;
        this.filePath = filePath;
    }

    public String getFileName() {
        return fileName;
    }

    public String getFilePath() {
        return filePath;
    }
}

