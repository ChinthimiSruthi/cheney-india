package com.example.chesney_india;

import java.util.List;

public class HelperClass {

    private String deviceId;
    private String qrCodeData;
    private List<String> mediaUrls;  // List of media URLs associated with the device

    // Default constructor for Firebase
    public HelperClass() {
    }

    // Constructor to initialize fields
    public HelperClass(String deviceId, String qrCodeData, List<String> mediaUrls) {
        this.deviceId = deviceId;
        this.qrCodeData = qrCodeData;
        this.mediaUrls = mediaUrls;
    }

    // Getter and setter for deviceId
    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    // Getter and setter for qrCodeData
    public String getQrCodeData() {
        return qrCodeData;
    }

    public void setQrCodeData(String qrCodeData) {
        this.qrCodeData = qrCodeData;
    }

    // Getter and setter for mediaUrls
    public List<String> getMediaUrls() {
        return mediaUrls;
    }

    public void setMediaUrls(List<String> mediaUrls) {
        this.mediaUrls = mediaUrls;
    }

    // Method to add a new media URL to the list
    public void addMediaUrl(String mediaUrl) {
        if (mediaUrls != null) {
            mediaUrls.add(mediaUrl);
        }
    }
}
