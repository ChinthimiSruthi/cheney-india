package com.example.chesney_india;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import java.util.List;

public class MediaAdapter extends RecyclerView.Adapter<MediaAdapter.MediaViewHolder> {

    private Context context;
    private List<String> mediaList;  // List of String (URLs)

    // Constructor that takes a List<String>
    public MediaAdapter(Context context, List<String> mediaList) {
        this.context = context;
        this.mediaList = mediaList;
    }

    @NonNull
    @Override
    public MediaViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the layout for each item in RecyclerView
        View view = LayoutInflater.from(context).inflate(R.layout.item_media, parent, false);
        return new MediaViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MediaViewHolder holder, int position) {
        // Get the media URL from the list (which is a String URL now)
        String mediaUrl = mediaList.get(position);

        // Load the image from the URL using Glide
        Glide.with(context)
                .load(mediaUrl)
                .into(holder.mediaImageView);
    }

    @Override
    public int getItemCount() {
        return mediaList.size();
    }

    // ViewHolder class to hold each media item view
    public static class MediaViewHolder extends RecyclerView.ViewHolder {
        ImageView mediaImageView;

        public MediaViewHolder(@NonNull View itemView) {
            super(itemView);
            mediaImageView = itemView.findViewById(R.id.mediaImageView);  // Bind to the ImageView
        }
    }
}
