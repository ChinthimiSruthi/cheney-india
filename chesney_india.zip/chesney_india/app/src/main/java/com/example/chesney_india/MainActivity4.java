package com.example.chesney_india;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.MediaItem;
import com.google.android.exoplayer2.Player;
import com.google.android.exoplayer2.ui.PlayerView;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;
import com.squareup.picasso.Picasso;

public class MainActivity4 extends AppCompatActivity {

    private static final String TAG = "MainActivity4";

    private ImageView imageView;
    private PlayerView playerView;
    private ExoPlayer exoPlayer;
    private ImageButton backButton;
    private FirebaseFirestore firestore;
    private ListenerRegistration mediaListener;
    private Handler handler = new Handler();
    private Runnable hideButtonRunnable = new Runnable() {
        @Override
        public void run() {
            backButton.setVisibility(View.INVISIBLE); // Hide the back button after 5 seconds of inactivity
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        // Hide the system UI for immersive mode
        hideSystemUI();

        // Initialize views
        imageView = findViewById(R.id.imageView);
        playerView = findViewById(R.id.playerView);
        backButton = findViewById(R.id.backButton);

        // Initialize Firestore
        firestore = FirebaseFirestore.getInstance();

        // Get the unique device ID
        String currentDeviceId = getUniqueDeviceId(); // Use the renamed method here

        // Listen for media updates from Firestore based on device ID
        listenForMediaUpdates("device_ids", currentDeviceId);

        // Initially make the back button invisible
        backButton.setVisibility(View.INVISIBLE);

        // Back button click listener
        backButton.setOnClickListener(v -> {
            releasePlayer();
            Intent intent = new Intent(MainActivity4.this, MainActivity3.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });

        // Show the back button on touch or cursor movement, and reset the timer
        findViewById(android.R.id.content).setOnTouchListener((v, event) -> {
            backButton.setVisibility(View.VISIBLE);
            handler.removeCallbacks(hideButtonRunnable);
            handler.postDelayed(hideButtonRunnable, 5000);
            return false;
        });

        findViewById(android.R.id.content).setOnGenericMotionListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_MOVE) {
                backButton.setVisibility(View.VISIBLE);
                handler.removeCallbacks(hideButtonRunnable);
                handler.postDelayed(hideButtonRunnable, 5000);
            }
            return false;
        });

        // Start the hide button timer
        handler.postDelayed(hideButtonRunnable, 5000);
    }

    private void hideSystemUI() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        );
    }

    @Override
    protected void onResume() {
        super.onResume();
        hideSystemUI();
    }

    private void listenForMediaUpdates(String collectionName, String deviceId) {
        DocumentReference docRef = firestore.collection(collectionName).document(deviceId);

        mediaListener = docRef.addSnapshotListener((documentSnapshot, e) -> {
            if (e != null) {
                Toast.makeText(this, "Failed to fetch media URL", Toast.LENGTH_SHORT).show();
                Log.e(TAG, "Firestore error: ", e);
                return;
            }

            if (documentSnapshot != null && documentSnapshot.exists()) {
                String mediaUrl = documentSnapshot.getString("media");
                if (mediaUrl != null) {
                    handleMedia(mediaUrl);
                } else {
                    Toast.makeText(this, "No media URL found", Toast.LENGTH_SHORT).show();
                    Log.e(TAG, "No media URL found in Firestore document.");
                }
            } else {
                Toast.makeText(this, "Document not found", Toast.LENGTH_SHORT).show();
                Log.e(TAG, "Firestore document does not exist.");
            }
        });
    }

    private void handleMedia(String mediaUrl) {
        releasePlayer();

        // Check if the media is a video or image by its URL
        if (isVideoUrl(mediaUrl)) {
            playVideo(mediaUrl);
        } else {
            displayImage(mediaUrl);
        }
    }

    private boolean isVideoUrl(String mediaUrl) {
        return mediaUrl.endsWith(".mp4") || mediaUrl.endsWith(".mov") || mediaUrl.endsWith(".avi");
    }

    private void displayImage(String imageUrl) {
        imageView.setVisibility(View.VISIBLE);
        playerView.setVisibility(View.GONE);

        Picasso.get()
                .load(imageUrl)
                .fit()
                .centerCrop()
                .into(imageView, new com.squareup.picasso.Callback() {
                    @Override
                    public void onSuccess() {
                        Log.d(TAG, "Image loaded successfully.");
                    }

                    @Override
                    public void onError(Exception e) {
                        Toast.makeText(MainActivity4.this, "Failed to load media", Toast.LENGTH_SHORT).show();
                        Log.e(TAG, "Error loading media as image: ", e);
                    }
                });
    }

    private void playVideo(String videoUrl) {
        imageView.setVisibility(View.GONE);
        playerView.setVisibility(View.VISIBLE);

        // Initialize ExoPlayer instance
        if (exoPlayer == null) {
            exoPlayer = new ExoPlayer.Builder(this).build();
            playerView.setPlayer(exoPlayer);
            playerView.setUseController(false);  // Disable player controls (no play/pause button)
        }

        MediaItem mediaItem = MediaItem.fromUri(Uri.parse(videoUrl));
        exoPlayer.setMediaItem(mediaItem);
        exoPlayer.prepare();
        exoPlayer.setPlayWhenReady(true);

        exoPlayer.addListener(new Player.Listener() {
            @Override
            public void onPlaybackStateChanged(int playbackState) {
                if (playbackState == Player.STATE_READY) {
                    Log.d(TAG, "Video is ready to play.");
                } else if (playbackState == Player.STATE_ENDED) {
                    Log.d(TAG, "Video playback ended.");
                }
            }

            @Override
            public void onPlayerError(com.google.android.exoplayer2.PlaybackException error) {
                Log.e(TAG, "Error playing video: ", error);
                Toast.makeText(MainActivity4.this, "Error playing video", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void releasePlayer() {
        if (exoPlayer != null) {
            exoPlayer.release();
            exoPlayer = null;
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (exoPlayer != null) {
            exoPlayer.pause();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        releasePlayer();
        if (mediaListener != null) {
            mediaListener.remove();
        }
    }

    // Renamed method to avoid conflict
    private String getUniqueDeviceId() {
        return android.provider.Settings.Secure.getString(getContentResolver(), android.provider.Settings.Secure.ANDROID_ID);
    }
}
